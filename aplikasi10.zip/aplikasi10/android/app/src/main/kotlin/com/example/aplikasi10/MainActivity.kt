package com.example.aplikasi10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
