import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RegisterController extends GetxController {
  final formKey = GlobalKey<FormState>();
  CollectionReference ref = FirebaseFirestore.instance.collection('User');
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  @override
  void onClose() {
    usernameController.dispose();
    nameController.dispose();
    emailController.dispose();
    addressController.dispose();
    phoneNumberController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.onClose();
  }

  Future<void> register(
    String username,
    String name,
    String email,
    String address,
    int phoneNumber,
    String password,
  ) async {
    if (formKey.currentState!.validate() &&
        email.isEmail &&
        password == confirmPasswordController.text) {
      try {
        final refDoc = ref.doc();
        final user = {
          "username": username,
          "name": name,
          "email": email,
          "address": address,
          "phoneNumber": phoneNumber,
          "password": password,
        };
        refDoc.set(user);
        Get.snackbar('Success', 'Registration successful');
        Get.offNamed('/login');
      } catch (error) {
        if (error is FirebaseException) {
          if (error.code == 'email-already-in-use') {
            Get.snackbar('Error', 'Email already registered');
          } else {
            Get.snackbar('Error', 'Registration failed: ${error.message}');
          }
        } else {
          Get.snackbar('Error', 'Registration failed: $error');
        }
      }
    } else if (password != confirmPasswordController.text) {
      Get.snackbar('Not success', 'Password does not match');
    } else {
      Get.snackbar('Not success', 'Please fill all fields correctly');
    }
  }
}
