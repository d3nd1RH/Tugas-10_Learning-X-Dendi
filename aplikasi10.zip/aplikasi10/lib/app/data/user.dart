class User {
  final String username;
  final String name;
  final String email;
  final String address;
  final int phoneNumber;
  final String password;

  User({
    required this.username,
    required this.name,
    required this.email,
    required this.address,
    required this.phoneNumber,
    required this.password,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      username: json['Username'] as String,
      name: json['Name'] as String,
      email: json['Email'] as String,
      address: json['Address'] as String,
      phoneNumber: json['Phone Number'] as int,
      password: json['Password'] as String,
    );
  }
}
